/* Imports for global scope */

_ = Package.underscore._;
HTTP = Package.http.HTTP;
HTTPInternals = Package.http.HTTPInternals;
Email = Package.email.Email;
EmailInternals = Package.email.EmailInternals;
Router = Package['iron:router'].Router;
RouteController = Package['iron:router'].RouteController;
MongoInternals = Package.mongo.MongoInternals;
Mongo = Package.mongo.Mongo;
Tracker = Package.tracker.Tracker;
Deps = Package.tracker.Deps;
Log = Package.logging.Log;
Random = Package.random.Random;
EJSON = Package.ejson.EJSON;
Spacebars = Package.spacebars.Spacebars;
check = Package.check.check;
Match = Package.check.Match;
Iron = Package['iron:core'].Iron;
Meteor = Package.meteor.Meteor;
WebApp = Package.webapp.WebApp;
main = Package.webapp.main;
WebAppInternals = Package.webapp.WebAppInternals;
DDP = Package['ddp-client'].DDP;
DDPServer = Package['ddp-server'].DDPServer;
LaunchScreen = Package['launch-screen'].LaunchScreen;
Blaze = Package.ui.Blaze;
UI = Package.ui.UI;
Handlebars = Package.ui.Handlebars;
Autoupdate = Package.autoupdate.Autoupdate;
HTML = Package.htmljs.HTML;

