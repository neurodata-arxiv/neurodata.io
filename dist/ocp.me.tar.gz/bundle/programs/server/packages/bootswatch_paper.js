(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['bootswatch:paper'] = {};

})();

//# sourceMappingURL=bootswatch_paper.js.map
